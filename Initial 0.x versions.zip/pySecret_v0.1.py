# Libraries needed to be installed:
#   $> pip install argon2-cffi 
#   $> pip install pynacl

# Importing Libraries
import os
import re
import threading
import time
import hashlib
import secrets
from datetime import datetime
from argon2.low_level import hash_secret_raw, Type
from nacl.bindings import (
    crypto_aead_xchacha20poly1305_ietf_encrypt,
    crypto_aead_xchacha20poly1305_ietf_decrypt,
    crypto_aead_xchacha20poly1305_ietf_NPUBBYTES,
)
from argon2.low_level import hash_secret_raw, Type 
from nacl.utils import random as nacl_random

# Globale Variable
globalSecret = None
secret_timer_thread = None

# IMPORTED PARAMETERS DEFAULTS
SECRET_EXPIRATION_IN_SECONDS=300
DEBUG_ON=False
RESULT_FILE_NAME='data.dta'


# Bildschirm löschen
def clear_screen():
    os.system('cls' if os.name == 'nt' else 'clear')

# Pause
def pause():
    input("\nBeliebige Taste drücken, um zum Hauptmenü zurückzukehren...")

# Parameter aus parameters.ini lesen
def read_parameters():
    global SECRET_EXPIRATION_IN_SECONDS
    global DEBUG_ON
    global RESULT_FILE_NAME

    if not os.path.exists("parameters.ini"):
        return

    try:
        with open("parameters.ini", "r") as f:
            lines = f.readlines()
    except Exception:
        return  # If file can't be read, keep defaults

    for raw_line in lines:
        line = raw_line.strip()

        if not line or line.startswith("#") or "=" not in line:
            continue

        key, value = line.split("=", 1)
        key = key.strip()
        value = value.strip()

        # Each variable handled independently
        if key == "SECRET_EXPIRATION_IN_SECONDS":
            try:
                SECRET_EXPIRATION_IN_SECONDS = int(value)
            except ValueError:
                pass  # Ignore invalid value only for this variable

        elif key == "DEBUG_ON":
            if value.lower() in ("true", "false"):
                DEBUG_ON = value.lower() == "true"

        elif key == "RESULT_FILE_NAME":
            if value:
                RESULT_FILE_NAME = value

# Countdown Prozess
def secret_countdown(seconds):
    global globalSecret
    time.sleep(seconds)
    globalSecret = None

# Hash String input
def normalize_string(param: str) -> str:
    # Allowed output characters
    charset = (
        "abcdefghijklmnopqrstuvwxyz"
        "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
        "0123456789"
        "@!&*$"
    )
    
    # Create deterministic hash
    digest = hashlib.sha256(param.encode("utf-8")).digest()
    
    # Map hash bytes to charset
    result = []
    for i in range(6):
        index = digest[i] % len(charset)
        result.append(charset[index])
    
    return "".join(result)

# Secret berechnen
def calculatePassword(quest1, quest2, quest3, quest4, quest5, date1, date2):
    if DEBUG_ON:
        print("===============================================")
        print("\n--- Zusammenfassung ---\n")
        print("quest1:", quest1)
        print("quest2:", quest2)
        print("quest3:", quest3)
        print("quest4:", quest4)
        print("quest5:", quest5)
        print("date1:", date1)
        print("date2:", date2)
        print("===============================================")
    
    # Apply string normalization to variables
    quest1 = normalize_string(quest1)
    quest2 = normalize_string(quest2)
    quest3 = normalize_string(quest3)
    quest4 = normalize_string(quest4)
    quest5 = normalize_string(quest5)
    date1 = normalize_string(date1)
    date2 = normalize_string(date2)

    if DEBUG_ON:
        print("\n--- Normalization Finished: ---\n")
        print("quest1:", quest1)
        print("quest2:", quest2)
        print("quest3:", quest3)
        print("quest4:", quest4)
        print("quest5:", quest5)
        print("date1:", date1)
        print("date2:", date2)

    # get secret 
    # Combine deterministically (fixed order)
    combPassword = "".join([
        quest1,
        quest2,
        quest3,
        quest4,
        quest5,
        date1,
        date2
    ]).encode("utf-8")

    if DEBUG_ON:
        print('DEBUG combined Password: ', combPassword)

    if DEBUG_ON:  
        print("===============================================")
    return combPassword

# Generate SALT Encryption
def generate_salt(length: int = 16) -> bytes:
    """
    Generate a cryptographically secure random salt.
    Recommended minimum: 16 bytes.
    """

    return secrets.token_bytes(length)

# Derive Encryption Key
def derive_key(password: str, salt: bytes) -> bytes:
    """
    Derive a 256-bit encryption key using Argon2id.
    Accepts password as str or bytes.
    """

    if isinstance(password, str):
        password_bytes = password.encode("utf-8")
    elif isinstance(password, bytes):
        password_bytes = password
    else:
        raise TypeError("Password must be str or bytes")

    return hash_secret_raw(
        secret=password_bytes,
        salt=salt,
        time_cost=3,           # Iterations (increase for more security)
        memory_cost=65536,     # 64 MB memory usage
        parallelism=4,
        hash_len=32,           # 256-bit key
        type=Type.ID
    )

# Option 1
def set_password():
    global globalSecret, secret_timer_thread

    clear_screen()

    def get_text_input(question):
        while True:
            value = input(question + ": ").strip()
            if re.fullmatch(r"[a-zA-Z]{3,15}", value):
                return value.lower()
            else:
                print("Ungültige Eingabe. Nur Buchstaben erlaubt (3–15 Zeichen).")

    
    def get_date_input(question):
        while True:
            value = input(question + " (ddmmyyyy): ").strip()

            # Check exact format: 8 digits
            if not value.isdigit() or len(value) != 8:
                print("Ungültiges Format. Bitte genau 8 Ziffern im Format ddmmyyyy eingeben.")
                continue

            # Validate real date
            try:
                datetime.strptime(value, "%d%m%Y")
                return value
            except ValueError:
                print("Ungültiges Datum. Bitte ein korrektes Kalenderdatum eingeben.")

    quest1 = get_text_input("Dein Lieblingsessen")
    quest2 = get_text_input("Name deines ersten Haustiers")
    quest3 = get_text_input("In welcher Stadt wurdest du geboren")
    quest4 = get_text_input("Name deines Lieblingscousins")
    quest5 = get_text_input("Name deiner ersten Freundin")
    date1 = get_date_input("Mutter Geburtsdatum")
    date2 = get_date_input("Wichtiges datum")

    secret = calculatePassword(quest1, quest2, quest3, quest4, quest5, date1, date2)
    globalSecret = secret

    # Countdown starten
    seconds = SECRET_EXPIRATION_IN_SECONDS
    if DEBUG_ON:
        print('DEBUG: SECRET_EXPIRATION_IN_SECONDS: ', seconds)
    secret_timer_thread = threading.Thread(target=secret_countdown, args=(seconds,), daemon=True)
    secret_timer_thread.start()
    print('===============================')
    print('Passwort erfolgreich generiert')
    pause()

# Option 2
def read_file():
    global globalSecret

    if globalSecret is None:
        clear_screen()
        print("WARNUNG: Kein Secret gesetzt. Bitte zuerst Option 1 ausführen.")
        pause()
        return

    if not os.path.exists(RESULT_FILE_NAME):
        clear_screen()
        print("Datei nicht gefunden.")
        pause()
        return

    clear_screen()

    try:
        # --- 1. Read file ---
        with open(RESULT_FILE_NAME, "rb") as f:
            content = f.read()

        # Fixed lengths
        SALT_LEN = 16
        NONCE_LEN = crypto_aead_xchacha20poly1305_ietf_NPUBBYTES  # 24 bytes

        # Basic structural validation
        if len(content) < SALT_LEN + NONCE_LEN + 16:
            raise ValueError("Ungültiges Dateiformat oder Datei zu klein.")

        # --- 2. Extract structured fields ---
        salt = content[:SALT_LEN]
        nonce = content[SALT_LEN:SALT_LEN + NONCE_LEN]
        ciphertext_with_tag = content[SALT_LEN + NONCE_LEN:]

        # --- 3. Derive key again using same password + salt ---
        key = derive_key(globalSecret, salt)

        # --- 4. Decrypt ---
        plaintext = crypto_aead_xchacha20poly1305_ietf_decrypt(
            ciphertext_with_tag,
            aad=None,
            nonce=nonce,
            key=key
        )

        print("Entschlüsselter Text:\n")
        print("############################################################")
        print(plaintext.decode("utf-8"))
        print("############################################################")
        pause()

    except Exception as e:
        # Covers:
        # - Wrong password
        # - Modified file
        # - Corrupted file
        print("Fehler beim Entschlüsseln.")
        print("Mögliche Ursachen:")
        print("- Falsches Passwort")
        print("- Datei wurde verändert")
        print("- Datei beschädigt")
        pause()

# Option 3
def write_file():
    global globalSecret
    if globalSecret is None:
        clear_screen()
        print("WARNUNG: Kein Secret gesetzt. Bitte zuerst Option 1 ausführen.")
        pause()
        return

    clear_screen()
     # Ask user for plaintext
    plaintext = input("Bitte Text zum Verschlüsseln eingeben: ").strip()

    if not plaintext:
        print("Kein Text eingegeben.")
        pause()
        return

    # --- 1. Generate Salt ---
    salt = generate_salt()

    # --- 2. Derive Key using Argon2id ---
    key = derive_key(globalSecret, salt)

    # --- print debug
    if DEBUG_ON:
        print(f"DEBUG globalSecret   : {globalSecret}")
        print(f"DEBUG salt (hex)     : {salt.hex()}")
        print(f"DEBUG hash key (hex) : {key.hex()}")

    # --- 3. Generate XChaCha20 nonce ---
    nonce = nacl_random(crypto_aead_xchacha20poly1305_ietf_NPUBBYTES)

    # --- 4. Encrypt ---
    ciphertext_with_tag = crypto_aead_xchacha20poly1305_ietf_encrypt(
        plaintext.encode("utf-8"),
        aad=None,
        nonce=nonce,
        key=key
    )

    # PyNaCl returns ciphertext + auth_tag combined.
    # Auth tag is last 16 bytes.
    auth_tag = ciphertext_with_tag[-16:]
    ciphertext = ciphertext_with_tag[:-16]

    # --- 5. Save file (overwrite completely) ---
    with open(RESULT_FILE_NAME, "wb") as f:
        f.write(salt + nonce + ciphertext_with_tag)

    print("Text erfolgreich verschlüsselt und gespeichert.")
    pause()

# Option 4
def write_details():
    global SECRET_EXPIRATION_IN_SECONDS
    global DEBUG_ON
    global RESULT_FILE_NAME
    clear_screen()
    print('=======================')
    print('Printing Imported variables from paramaters.ini or default.')
    print('SECRET_EXPIRATION_IN_SECONDS=',SECRET_EXPIRATION_IN_SECONDS)
    print('DEBUG_ON=',DEBUG_ON)
    print('RESULT_FILE_NAME=',RESULT_FILE_NAME)
    print('=======================')
    pause()

# Hauptmenü
def main_menu():
    # read external parameters    
    read_parameters()

    # print menu
    while True:
        clear_screen()
        print("===== HAUPTMENÜ =====")
        print("1 - Pass setzen")
        print("2 - Lesen")
        print("3 - Schreiben")
        print("8 - Details")
        print("9 - End")

        choice = input("\nOp wählen: ").strip()

        if choice == "1":
            set_password()
        elif choice == "2":
            read_file()
        elif choice == "3":
            write_file()
        elif choice == "8":
            write_details()
        elif choice == "9":
            clear_screen()
            print("Programm beendet.")
            break
        else:
            clear_screen()
            print("Ungültige Option.")
            time.sleep(1)

if __name__ == "__main__":
    main_menu()
