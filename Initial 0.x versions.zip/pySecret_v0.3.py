# Libraries needed to be installed:
#   $> pip install argon2-cffi 
#   $> pip install pynacl

# Importing Libraries
import os
import re
import threading
import time
import hashlib
import secrets
from datetime import datetime
from argon2.low_level import hash_secret_raw, Type
from nacl.bindings import (
    crypto_aead_xchacha20poly1305_ietf_encrypt,
    crypto_aead_xchacha20poly1305_ietf_decrypt,
    crypto_aead_xchacha20poly1305_ietf_NPUBBYTES,    
)
from argon2.low_level import hash_secret_raw, Type 
from nacl.utils import random as nacl_random

# Globale Variable
globalSecret = None
secret_timer_thread = None
SALT_LEN = 16
NONCE_LEN = crypto_aead_xchacha20poly1305_ietf_NPUBBYTES

# IMPORTED PARAMETERS DEFAULTS
SECRET_EXPIRATION_IN_SECONDS=300
DEBUG_ON=False
RESULT_FILE_NAME='data.dta'


# HELPER FUNCTIONS:
# Bildschirm löschen
def clear_screen():
    os.system('cls' if os.name == 'nt' else 'clear')

# Pause
def pause():
    print("---------------------------------------------")
    input("\nPress any key to continue...")

# Parameter aus parameters.ini lesen
def read_parameters():
    global SECRET_EXPIRATION_IN_SECONDS
    global DEBUG_ON
    global RESULT_FILE_NAME

    if not os.path.exists("parameters.ini"):
        return

    try:
        with open("parameters.ini", "r") as f:
            lines = f.readlines()
    except Exception:
        return  # If file can't be read, keep defaults

    for raw_line in lines:
        line = raw_line.strip()

        if not line or line.startswith("#") or "=" not in line:
            continue

        key, value = line.split("=", 1)
        key = key.strip()
        value = value.strip()

        # Each variable handled independently
        if key == "SECRET_EXPIRATION_IN_SECONDS":
            try:
                SECRET_EXPIRATION_IN_SECONDS = int(value)
            except ValueError:
                pass  # Ignore invalid value only for this variable

        elif key == "DEBUG_ON":
            if value.lower() in ("true", "false"):
                DEBUG_ON = value.lower() == "true"

        elif key == "RESULT_FILE_NAME":
            if value:
                RESULT_FILE_NAME = value

# Countdown Prozess
def secret_countdown(seconds):
    global globalSecret
    time.sleep(seconds)
    globalSecret = None

# Hash String input
def normalize_string(param: str) -> str:
    # Allowed output characters
    charset = (
        "abcdefghijklmnopqrstuvwxyz"
        "ABCDEFGHIJKLMNOPQRSTUVWXYZ"
        "0123456789"
        "@!&*$"
    )
    
    # Create deterministic hash
    digest = hashlib.sha256(param.encode("utf-8")).digest()
    
    # Map hash bytes to charset
    result = []
    for i in range(6):
        index = digest[i] % len(charset)
        result.append(charset[index])
    
    return "".join(result)

# Secret berechnen
def calculatePassword(quest1, quest2, quest3, quest4, quest5, date1, date2):
    if DEBUG_ON:
        print("===============================================")
        print("\n--- Summary Entries ---\n")
        print("quest1:", quest1)
        print("quest2:", quest2)
        print("quest3:", quest3)
        print("quest4:", quest4)
        print("quest5:", quest5)
        print("date1:", date1)
        print("date2:", date2)
        print("===============================================")
    
    # Apply string normalization to variables
    quest1 = normalize_string(quest1)
    quest2 = normalize_string(quest2)
    quest3 = normalize_string(quest3)
    quest4 = normalize_string(quest4)
    quest5 = normalize_string(quest5)
    date1 = normalize_string(date1)
    date2 = normalize_string(date2)

    if DEBUG_ON:
        print("\n--- Normalization Finished: ---\n")
        print("quest1:", quest1)
        print("quest2:", quest2)
        print("quest3:", quest3)
        print("quest4:", quest4)
        print("quest5:", quest5)
        print("date1:", date1)
        print("date2:", date2)

    # get secret 
    # Combine deterministically (fixed order)
    combPassword = "".join([
        quest1,
        quest2,
        quest3,
        quest4,
        quest5,
        date1,
        date2
    ]).encode("utf-8")

    if DEBUG_ON:
        print('DEBUG combined Password: ', combPassword)

    if DEBUG_ON:  
        print("===============================================")
    return combPassword

# Generate SALT Encryption
def generate_salt(length: int = 16) -> bytes:
    """
    Generate a cryptographically secure random salt.
    Recommended minimum: 16 bytes.
    """

    return secrets.token_bytes(length)

# Derive Encryption Key
def derive_key(password: str, salt: bytes) -> bytes:
    """
    Derive a 256-bit encryption key using Argon2id.
    Accepts password as str or bytes.
    """

    if isinstance(password, str):
        password_bytes = password.encode("utf-8")
    elif isinstance(password, bytes):
        password_bytes = password
    else:
        raise TypeError("Password must be str or bytes")

    return hash_secret_raw(
        secret=password_bytes,
        salt=salt,
        time_cost=3,           # Iterations (increase for more security)
        memory_cost=65536,     # 64 MB memory usage
        parallelism=4,
        hash_len=32,           # 256-bit key
        type=Type.ID
    )

# Encrypt
def encrypt_and_write(plaintext: str):
    """
    Encrypt full plaintext and overwrite file.
    """
    salt = generate_salt()
    key = derive_key(globalSecret, salt)
    nonce = nacl_random(NONCE_LEN)

    if DEBUG_ON:
        print(f"DEBUG - password    : {globalSecret}")
        print(f"DEBUG - salt        : {salt.hex()}")
        print(f"DEBUG - Derived Key : {key.hex()}")
        print(f"DEBUG - nonce        : {nonce.hex()}")
        

    ciphertext_with_tag = crypto_aead_xchacha20poly1305_ietf_encrypt(
        plaintext.encode("utf-8"),
        aad=None,
        nonce=nonce,
        key=key
    )

    with open(RESULT_FILE_NAME, "wb") as f:
        f.write(salt + nonce + ciphertext_with_tag)

# Decrypt
def decrypt_existing_file():
    """
    Decrypt existing file and return plaintext string.
    Returns empty string if file does not exist.
    Raises exception if decryption fails.
    """
    if not os.path.exists(RESULT_FILE_NAME):
        return ""

    with open(RESULT_FILE_NAME, "rb") as f:
        content = f.read()

    if len(content) < SALT_LEN + NONCE_LEN + 16:
        raise ValueError("Invalid file format.")

    salt = content[:SALT_LEN]
    nonce = content[SALT_LEN:SALT_LEN + NONCE_LEN]
    ciphertext_with_tag = content[SALT_LEN + NONCE_LEN:]

    key = derive_key(globalSecret, salt)

    plaintext = crypto_aead_xchacha20poly1305_ietf_decrypt(
        ciphertext_with_tag,
        aad=None,
        nonce=nonce,
        key=key
    )

    return plaintext.decode("utf-8")

# MAIN MENU OPTIONS:
# Option 1
def set_password():
    global globalSecret, secret_timer_thread

    clear_screen()

    def get_text_input(question):
        while True:
            value = input(question + ": ").strip()
            if re.fullmatch(r"[a-zA-Z]{3,15}", value):
                return value.lower()
            else:
                print("Invalid entry. Only letters allowed (3–15 characters).")

    
    def get_date_input(question):
        while True:
            value = input(question + " (ddmmyyyy): ").strip()

            # Check exact format: 8 digits
            if not value.isdigit() or len(value) != 8:
                print("Invalid format. Please enter exactly 8 digits in the format ddmmyyyy.")
                continue

            # Validate real date
            try:
                datetime.strptime(value, "%d%m%Y")
                return value
            except ValueError:
                print("Invalid date. Please enter a valid calendar date.")

    quest1 = get_text_input("Your favorite food")
    quest2 = get_text_input("Name of your first pet")
    quest3 = get_text_input("In which city were you born")
    quest4 = get_text_input("Favorite musical instrument")
    quest5 = get_text_input("Favorite writer (FirstnameLastname)")
    date1 = get_date_input("Mother's date of birth")
    date2 = get_date_input("Date of first employment")

    secret = calculatePassword(quest1, quest2, quest3, quest4, quest5, date1, date2)
    globalSecret = secret

    # Countdown starten
    seconds = SECRET_EXPIRATION_IN_SECONDS
    if DEBUG_ON:
        print('DEBUG: SECRET_EXPIRATION_IN_SECONDS: ', seconds)
        print('===============================')
    secret_timer_thread = threading.Thread(target=secret_countdown, args=(seconds,), daemon=True)
    secret_timer_thread.start()
    
    print('Password successfully generated')
    pause()

# Option 2
def read_file():
    global globalSecret

    if globalSecret is None:
        clear_screen()
        print("WARNING: No secret set. Please run Option 1 first.")
        pause()
        return

    clear_screen()

    try:
        plaintext = decrypt_existing_file()

        if not plaintext:
            print("File empty or not available")
        else:
            print("Decrypted text:\n")
            print("############################################################")
            print(plaintext)
            print("############################################################")

        pause()

    except Exception:
        print("Error during decryption.")
        print("Possible causes:")
        print("- Incorrect password")
        print("- The file has been modified")
        print("- The file is corrupted")
        pause()

# Option 3
def write_file():
    global globalSecret

    if globalSecret is None:
        clear_screen()
        print("WARNING: No secret has been set. Please run Option 1 first.")
        pause()
        return

    clear_screen()

    new_text = input("Please enter text to encrypt: ").strip()

    if not new_text:
        print("No text was entered.")
        pause()
        return

    try:
        # --- 1. Decrypt existing content (if file exists) ---
        existing_text = decrypt_existing_file()

        # --- 2. Create timestamp ---
        timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

        # Format line
        new_entry = f"[{timestamp}] {new_text}"

        # --- 3. Prepend new entry (newest first) ---
        if existing_text:
            full_text = new_entry + "\n" + existing_text
        else:
            full_text = new_entry

        # --- 4. Encrypt everything again with NEW salt + nonce ---
        encrypt_and_write(full_text)

        print("Text successfully encrypted and saved.")
        pause()

    except Exception:
        print("Error processing the file.")
        print("Possible causes:")
        print("- Incorrect password")
        print("- The file has been modified")
        print("- The file is corrupted")
        pause()
        
# Option 4
def write_details():
    global SECRET_EXPIRATION_IN_SECONDS
    global DEBUG_ON
    global RESULT_FILE_NAME
    clear_screen()
    print('=======================')
    print('Printing Imported variables from paramaters.ini or default.')
    print('SECRET_EXPIRATION_IN_SECONDS=',SECRET_EXPIRATION_IN_SECONDS)
    print('DEBUG_ON=',DEBUG_ON)
    print('RESULT_FILE_NAME=',RESULT_FILE_NAME)
    print('=======================')
    pause()

# Main Menu
def main_menu():
    # read external parameters    
    read_parameters()

    # print menu
    while True:
        clear_screen()
        print("===== MAIN MENU =====")
        print("1 - Set Password")
        print("2 - Read File")
        print("3 - Write File")
        print("8 - Print Parameters")
        print("9 - Exit")

        choice = input("\nSelect Option: ").strip()

        if choice == "1":
            set_password()
        elif choice == "2":
            read_file()
        elif choice == "3":
            write_file()
        elif choice == "8":
            write_details()
        elif choice == "9":
            clear_screen()
            print("Program Exited.")
            break
        else:
            clear_screen()
            print("Invalid Option.")
            time.sleep(1)

if __name__ == "__main__":
    main_menu()
